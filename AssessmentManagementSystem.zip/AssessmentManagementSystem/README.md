##Please run the below DDL query before you execute this application.  

create table Trainee_details(details_id number(20) primary key,trainee_name varchar2(20),module_name varchar2(12),Mpt_marks NUMBER(20),mtt_marks NUMBER(5),assignment_marks NUMBER(5),total NUMBER(5));