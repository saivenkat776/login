package com.cg.jpastart.entities;
import java.io.IOException;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Traineetest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Trainee tr=new Trainee();
		Scanner sc=new Scanner(System.in);
		boolean a=true;
		while(a) {
		System.out.println("enter details Id");
		int id=sc.nextInt();
		System.out.println("enter trainee name");
		String str=sc.next();
		System.out.println("enter module name");
		String str1=sc.next();
		System.out.println("enter MPT marks");
		int mpt=sc.nextInt();
		System.out.println("enter MTT marks");
		int mtt=sc.nextInt();
		System.out.println("enter Assignment marks");
		int ass=sc.nextInt();
		
		if(mpt<=70 && mtt<=40 && ass<=15) {
		tr.setDetails_id(id);
		tr.setTrainee_name(str);
		tr.setModule_name(str1);
		tr.setMpt_marks(mpt);
		tr.setMtt_marks(mtt);
		tr.setAssignment_marks(ass);
		tr.getsum(mpt, mtt, ass);
		em.persist(tr);
		System.out.println("Added one trainee information to database.");
			em.getTransaction().commit();
		em.close();
		factory.close();
		a=false;
	}
			else {
				System.out.println("Enter correct details\n maximum MPT marks=70\nmaximum MTT marks=40\nmaximum Assignment marks=15");
			break;
			}
}
}
}
